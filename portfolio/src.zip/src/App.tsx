import React, { useState } from 'react';
import type { PortfolioProject } from './data/portfolioData';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { BrandMarquee } from './components/BrandMarquee';
import { WorkGallery } from './components/WorkGallery';
import { LightBoxModal } from './components/LightBoxModal';
import { LogoViewerModal } from './components/LogoViewerModal';
import { VideoModal } from './components/VideoModal';
import { AboutSection } from './components/AboutSection';
import { Services } from './components/Services';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';

export const App: React.FC = () => {
  const [selectedProject, setSelectedProject] = useState<PortfolioProject | null>(null);

  const handleCloseModal = () => {
    setSelectedProject(null);
  };

  return (
    <div className="min-h-screen bg-[#07090e] text-white selection:bg-indigo-500 selection:text-white relative">
      {/* Dynamic Ambient Background Orbs */}
      <div className="ambient-background">
        <div className="glow-orb glow-orb-1"></div>
        <div className="glow-orb glow-orb-2"></div>
        <div className="glow-orb glow-orb-3"></div>
      </div>

      {/* Main Layout Navigation */}
      <Navbar />

      {/* Main Page Sections */}
      <main className="relative z-10">
        <Hero />
        <BrandMarquee />
        <WorkGallery onSelectProject={(project) => setSelectedProject(project)} />
        <AboutSection />
        <Services />
        <ContactSection />
      </main>

      {/* Footer */}
      <Footer />

      {/* Modals for Interactive Previews */}
      {selectedProject && selectedProject.category === 'Graphics Design' && (
        <LightBoxModal project={selectedProject} onClose={handleCloseModal} />
      )}

      {selectedProject && selectedProject.category === 'Logo & Brand Identity' && (
        <LogoViewerModal project={selectedProject} onClose={handleCloseModal} />
      )}

      {selectedProject && selectedProject.category === 'Video Editing' && (
        <VideoModal project={selectedProject} onClose={handleCloseModal} />
      )}
    </div>
  );
};

export default App;
