import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { PORTFOLIO_PROJECTS, type PortfolioProject } from '../data/portfolioData';
import { Layers, Film, Eye, Sparkles, Filter, Search, Play, BookOpen, Images } from 'lucide-react';

interface WorkGalleryProps {
  onSelectProject: (project: PortfolioProject) => void;
}

export const WorkGallery: React.FC<WorkGalleryProps> = ({ onSelectProject }) => {
  const [activeCategory, setActiveCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedBrandFilter, setSelectedBrandFilter] = useState<string>('All');

  const categories = [
    { id: 'All', label: 'All Works', icon: Layers, count: PORTFOLIO_PROJECTS.length },
    {
      id: 'Graphics Design',
      label: 'Graphics & Ad Creatives',
      icon: Images,
      count: PORTFOLIO_PROJECTS.filter((p) => p.category === 'Graphics Design').length,
    },
    {
      id: 'Logo & Brand Identity',
      label: 'Logo & Style Guides',
      icon: BookOpen,
      count: PORTFOLIO_PROJECTS.filter((p) => p.category === 'Logo & Brand Identity').length,
    },
    {
      id: 'Video Editing',
      label: 'Video Editing & Reels',
      icon: Film,
      count: PORTFOLIO_PROJECTS.filter((p) => p.category === 'Video Editing').length,
    },
  ];

  const brandOptions = useMemo(() => {
    const brands = Array.from(new Set(PORTFOLIO_PROJECTS.map((p) => p.brand)));
    return ['All', ...brands];
  }, []);

  const filteredProjects = useMemo(() => {
    return PORTFOLIO_PROJECTS.filter((project) => {
      const matchCategory = activeCategory === 'All' || project.category === activeCategory;
      const matchBrand = selectedBrandFilter === 'All' || project.brand === selectedBrandFilter;
      const matchSearch =
        searchQuery === '' ||
        project.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        project.brand.toLowerCase().includes(searchQuery.toLowerCase()) ||
        project.tag.toLowerCase().includes(searchQuery.toLowerCase()) ||
        project.description.toLowerCase().includes(searchQuery.toLowerCase());
      return matchCategory && matchBrand && matchSearch;
    });
  }, [activeCategory, selectedBrandFilter, searchQuery]);

  return (
    <section id="works" className="py-24 relative bg-[#07090e]">
      <div className="portfolio-container">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-12">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-indigo-300 text-xs font-semibold uppercase tracking-wider">
            <Sparkles size={14} className="text-indigo-400" />
            Selected Portfolio Showcase
          </div>
          <h2 className="font-heading text-3xl sm:text-4xl md:text-5xl font-extrabold text-white">
            Featured <span className="text-gradient-vibrant">Design & Motion</span> Works
          </h2>
          <p className="text-gray-400 text-base sm:text-lg">
            Explore 150+ social media carousels, brand style guides, and commercial motion reels created for diverse client brands over 3+ years.
          </p>
        </div>

        {/* Filter Controls */}
        <div className="space-y-6 mb-12">
          
          {/* Main Category Tabs */}
          <div className="flex flex-wrap items-center justify-center gap-2 bg-white/[0.03] p-2 rounded-2xl border border-white/10 max-w-4xl mx-auto backdrop-blur-xl">
            {categories.map((cat) => {
              const Icon = cat.icon;
              const isActive = activeCategory === cat.id;
              return (
                <button
                  key={cat.id}
                  onClick={() => {
                    setActiveCategory(cat.id);
                    setSelectedBrandFilter('All');
                  }}
                  className={`flex items-center gap-2.5 px-5 py-3 rounded-xl font-semibold text-sm transition-all duration-300 ${
                    isActive
                      ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow-lg shadow-indigo-500/30'
                      : 'text-gray-300 hover:text-white hover:bg-white/10'
                  }`}
                >
                  <Icon size={17} className={isActive ? 'text-white' : 'text-indigo-400'} />
                  {cat.label}
                  <span
                    className={`text-xs px-2 py-0.5 rounded-full ${
                      isActive ? 'bg-white/20 text-white' : 'bg-white/5 text-gray-400'
                    }`}
                  >
                    {cat.count}
                  </span>
                </button>
              );
            })}
          </div>

          {/* Sub-Filters & Search Bar */}
          <div className="flex flex-wrap items-center justify-between gap-4 bg-white/[0.02] p-4 rounded-2xl border border-white/5">
            {/* Search Input */}
            <div className="relative flex-1 min-w-[240px]">
              <Search size={18} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400" />
              <input
                type="text"
                placeholder="Search by brand, category, keyword..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-white/5 border border-white/10 rounded-xl pl-10 pr-4 py-2.5 text-sm text-white placeholder-gray-400 focus:outline-none focus:border-indigo-500 transition-colors"
              />
            </div>

            {/* Brand Filter Dropdown */}
            <div className="flex items-center gap-2 overflow-x-auto pb-1 max-w-full">
              <Filter size={16} className="text-indigo-400 flex-shrink-0" />
              <span className="text-xs font-semibold text-gray-400 flex-shrink-0">Brand:</span>
              <select
                value={selectedBrandFilter}
                onChange={(e) => setSelectedBrandFilter(e.target.value)}
                className="bg-white/5 border border-white/10 rounded-xl px-3 py-2 text-xs text-indigo-300 font-semibold focus:outline-none focus:border-indigo-500"
              >
                {brandOptions.map((brand) => (
                  <option key={brand} value={brand} className="bg-[#0b0f19] text-white">
                    {brand}
                  </option>
                ))}
              </select>
            </div>
          </div>

        </div>

        {/* Projects Grid */}
        {filteredProjects.length === 0 ? (
          <div className="text-center py-16 bg-white/[0.02] rounded-3xl border border-white/5">
            <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-indigo-500/10 flex items-center justify-center text-indigo-400">
              <Search size={32} />
            </div>
            <h3 className="text-xl font-bold text-white mb-2">No projects found</h3>
            <p className="text-gray-400 text-sm">Try tweaking your search term or category filters.</p>
            <button
              onClick={() => {
                setActiveCategory('All');
                setSelectedBrandFilter('All');
                setSearchQuery('');
              }}
              className="btn-secondary mt-4 py-2 px-4 text-xs"
            >
              Reset Filters
            </button>
          </div>
        ) : (
          <motion.div layout className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <AnimatePresence>
              {filteredProjects.map((project) => (
                <motion.div
                  key={project.id}
                  layout
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.9 }}
                  transition={{ duration: 0.3 }}
                  onClick={() => onSelectProject(project)}
                  className="glass-panel glass-panel-hover rounded-2xl overflow-hidden cursor-pointer group flex flex-col justify-between"
                >
                  {/* Card Media Preview Container */}
                  <div className="relative aspect-[4/3] bg-[#07090e] overflow-hidden">
                    
                    {project.coverImage ? (
                      <img
                        src={project.coverImage}
                        alt={project.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                        loading="lazy"
                      />
                    ) : project.category === 'Video Editing' ? (
                      <div className="w-full h-full bg-gradient-to-tr from-indigo-950 via-slate-900 to-purple-950 flex flex-col items-center justify-center p-6 text-center">
                        <div className="w-16 h-16 rounded-full bg-indigo-600/30 border border-indigo-400/50 flex items-center justify-center text-indigo-300 mb-3 group-hover:scale-110 transition-transform">
                          <Play size={28} className="ml-1 text-white fill-white" />
                        </div>
                        <span className="font-heading font-bold text-white text-base">
                          {project.title}
                        </span>
                      </div>
                    ) : null}

                    {/* Gradient Overlay */}
                    <div className="absolute inset-0 bg-gradient-to-t from-[#0b0f19] via-transparent to-transparent opacity-80 group-hover:opacity-90 transition-opacity"></div>

                    {/* Top Badges */}
                    <div className="absolute top-3 left-3 right-3 flex items-center justify-between pointer-events-none">
                      <span className="badge-tag bg-[#0b0f19]/80 backdrop-blur-md border-white/10 text-white font-bold">
                        {project.brand}
                      </span>
                      <span className="px-2.5 py-1 rounded-full text-[11px] font-bold bg-indigo-600/80 backdrop-blur-md text-white border border-indigo-400/30 flex items-center gap-1 shadow-md">
                        {project.type === 'carousel' && <Images size={12} />}
                        {project.type === 'pdf_booklet' && <BookOpen size={12} />}
                        {project.type === 'video_gallery' && <Film size={12} />}
                        {project.type === 'carousel' && `${project.itemCount} Slides`}
                        {project.type === 'static' && `1 Image`}
                        {project.type === 'pdf_booklet' && `${project.pageCount || project.itemCount} Pages Guide`}
                        {project.type === 'video_gallery' && `${project.itemCount} Video Reels`}
                      </span>
                    </div>

                    {/* Center Action Overlay on Hover */}
                    <div className="absolute inset-0 flex items-center justify-center bg-indigo-950/60 backdrop-blur-sm opacity-0 group-hover:opacity-100 transition-all duration-300">
                      <div className="btn-primary py-2.5 px-5 text-sm transform translate-y-2 group-hover:translate-y-0 transition-transform">
                        {project.category === 'Video Editing' ? (
                          <>
                            <Play size={16} className="fill-white" /> Play Video Reel
                          </>
                        ) : project.category === 'Logo & Brand Identity' ? (
                          <>
                            <BookOpen size={16} /> Open Style Guide
                          </>
                        ) : (
                          <>
                            <Eye size={16} /> View Creatives
                          </>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Card Content Info */}
                  <div className="p-5 flex-1 flex flex-col justify-between space-y-3">
                    <div>
                      <div className="flex items-center justify-between gap-2 mb-1">
                        <span className="text-xs font-semibold text-indigo-400 uppercase tracking-wider">
                          {project.tag}
                        </span>
                      </div>
                      <h3 className="font-heading font-bold text-lg text-white group-hover:text-indigo-300 transition-colors line-clamp-1">
                        {project.title}
                      </h3>
                      <p className="text-xs text-gray-400 line-clamp-2 mt-1 leading-relaxed">
                        {project.description}
                      </p>
                    </div>

                    <div className="pt-3 border-t border-white/5 flex items-center justify-between text-xs text-gray-400">
                      <span className="flex items-center gap-1 font-medium text-gray-300">
                        {project.category}
                      </span>
                      <span className="text-indigo-400 font-semibold group-hover:translate-x-1 transition-transform inline-flex items-center gap-1">
                        Inspect &rarr;
                      </span>
                    </div>
                  </div>

                </motion.div>
              ))}
            </AnimatePresence>
          </motion.div>
        )}

      </div>
    </section>
  );
};
