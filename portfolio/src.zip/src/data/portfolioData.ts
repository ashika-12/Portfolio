export interface GraphicImage {
  filename: string;
  url: string;
}

export interface PDFPage {
  filename: string;
  url: string;
}

export interface VideoItem {
  filename: string;
  url: string;
  title: string;
}

export interface PortfolioProject {
  id: string;
  category: 'Graphics Design' | 'Logo & Brand Identity' | 'Video Editing';
  brand: string;
  folderName?: string;
  title: string;
  tag: string;
  description: string;
  coverImage?: string;
  images?: GraphicImage[];
  pdfUrl?: string;
  pages?: PDFPage[];
  pageCount?: number;
  videos?: VideoItem[];
  type: 'carousel' | 'static' | 'pdf_booklet' | 'video_gallery';
  itemCount: number;
}

export const PORTFOLIO_PROJECTS: PortfolioProject[] = [
  {
    "id": "gfx-ard-solutions---banglore",
    "category": "Graphics Design",
    "brand": "ARD Solutions",
    "folderName": "ARD Solutions - Banglore",
    "title": "ARD Solutions Social & Ad Creatives",
    "tag": "IT & Corporate Solutions",
    "description": "B2B manufacturer static ads and IT enterprise solutions graphics.",
    "coverImage": "/raw_assets/graphics/ARD Solutions - Banglore/Manufacturer - Static. 2.png",
    "images": [
      {
        "filename": "Manufacturer - Static. 2.png",
        "url": "/raw_assets/graphics/ARD Solutions - Banglore/Manufacturer - Static. 2.png"
      },
      {
        "filename": "Manufacturer - Static.png",
        "url": "/raw_assets/graphics/ARD Solutions - Banglore/Manufacturer - Static.png"
      }
    ],
    "type": "carousel",
    "itemCount": 2
  },
  {
    "id": "gfx-bocs-pizza",
    "category": "Graphics Design",
    "brand": "BOCS Pizza",
    "folderName": "BOCS PIZZA",
    "title": "BOCS Pizza Social & Ad Creatives",
    "tag": "F&B Festival Creatives",
    "description": "Vibrant holiday, festival (Holi, Onam), and promotional food social media campaigns.",
    "coverImage": "/raw_assets/graphics/BOCS PIZZA/holi bocs.jpg",
    "images": [
      {
        "filename": "holi bocs.jpg",
        "url": "/raw_assets/graphics/BOCS PIZZA/holi bocs.jpg"
      },
      {
        "filename": "madurai bocs .jpg",
        "url": "/raw_assets/graphics/BOCS PIZZA/madurai bocs .jpg"
      },
      {
        "filename": "onam bocs.jpg",
        "url": "/raw_assets/graphics/BOCS PIZZA/onam bocs.jpg"
      },
      {
        "filename": "women_s day bocs.jpg",
        "url": "/raw_assets/graphics/BOCS PIZZA/women_s day bocs.jpg"
      }
    ],
    "type": "carousel",
    "itemCount": 4
  },
  {
    "id": "gfx-curry-life",
    "category": "Graphics Design",
    "brand": "Curry Life",
    "folderName": "Curry Life",
    "title": "Curry Life Social & Ad Creatives",
    "tag": "Culinary & FMCG",
    "description": "Multi-slide promotional carousels & institutional supplier social media designs.",
    "coverImage": "/raw_assets/graphics/Curry Life/Curry life - carousel (1).png",
    "images": [
      {
        "filename": "Curry life - carousel (1).png",
        "url": "/raw_assets/graphics/Curry Life/Curry life - carousel (1).png"
      },
      {
        "filename": "Curry life - carousel (2).png",
        "url": "/raw_assets/graphics/Curry Life/Curry life - carousel (2).png"
      },
      {
        "filename": "Curry life - carousel (3).png",
        "url": "/raw_assets/graphics/Curry Life/Curry life - carousel (3).png"
      },
      {
        "filename": "Curry life -Carousel 1_Feb2025_1-1.png",
        "url": "/raw_assets/graphics/Curry Life/Curry life -Carousel 1_Feb2025_1-1.png"
      },
      {
        "filename": "Curry life -Carousel 2_Feb2025_1-1.png",
        "url": "/raw_assets/graphics/Curry Life/Curry life -Carousel 2_Feb2025_1-1.png"
      },
      {
        "filename": "Curry life -Carousel 3_Feb2025_1-1.png",
        "url": "/raw_assets/graphics/Curry Life/Curry life -Carousel 3_Feb2025_1-1.png"
      },
      {
        "filename": "Curry life -Institutional Supplier_Static2_1-1 .png",
        "url": "/raw_assets/graphics/Curry Life/Curry life -Institutional Supplier_Static2_1-1 .png"
      },
      {
        "filename": "Curry life -Institutional Supplier_Static_1-1 .png",
        "url": "/raw_assets/graphics/Curry Life/Curry life -Institutional Supplier_Static_1-1 .png"
      }
    ],
    "type": "carousel",
    "itemCount": 8
  },
  {
    "id": "gfx-e-now-batteries",
    "category": "Graphics Design",
    "brand": "E-Now Batteries",
    "folderName": "E-Now Batteries",
    "title": "E-Now Batteries Social & Ad Creatives",
    "tag": "Tech & Industrial",
    "description": "High-impact tech product carousels & battery features highlights.",
    "coverImage": "/raw_assets/graphics/E-Now Batteries/1.png",
    "images": [
      {
        "filename": "1.png",
        "url": "/raw_assets/graphics/E-Now Batteries/1.png"
      },
      {
        "filename": "2.png",
        "url": "/raw_assets/graphics/E-Now Batteries/2.png"
      },
      {
        "filename": "3.png",
        "url": "/raw_assets/graphics/E-Now Batteries/3.png"
      },
      {
        "filename": "E- Now Enables creatives - June 2025 .png",
        "url": "/raw_assets/graphics/E-Now Batteries/E- Now Enables creatives - June 2025 .png"
      },
      {
        "filename": "Enow- Carousel - 2.png",
        "url": "/raw_assets/graphics/E-Now Batteries/Enow- Carousel - 2.png"
      },
      {
        "filename": "Enow- Carousel - 3.png",
        "url": "/raw_assets/graphics/E-Now Batteries/Enow- Carousel - 3.png"
      }
    ],
    "type": "carousel",
    "itemCount": 6
  },
  {
    "id": "gfx-kanmani",
    "category": "Graphics Design",
    "brand": "Kanmani Milk",
    "folderName": "Kanmani",
    "title": "Kanmani Milk Social & Ad Creatives",
    "tag": "Dairy & Consumer Goods",
    "description": "Fresh dairy milk promotional posters and consumer graphics.",
    "coverImage": "/raw_assets/graphics/Kanmani/KANMANI 2.jpg",
    "images": [
      {
        "filename": "KANMANI 2.jpg",
        "url": "/raw_assets/graphics/Kanmani/KANMANI 2.jpg"
      },
      {
        "filename": "KANMANI 3.jpg",
        "url": "/raw_assets/graphics/Kanmani/KANMANI 3.jpg"
      },
      {
        "filename": "kanmani milk.jpg",
        "url": "/raw_assets/graphics/Kanmani/kanmani milk.jpg"
      }
    ],
    "type": "carousel",
    "itemCount": 3
  },
  {
    "id": "gfx-meddipro",
    "category": "Graphics Design",
    "brand": "Meddipro",
    "folderName": "Meddipro",
    "title": "Meddipro Social & Ad Creatives",
    "tag": "Healthcare & Surgical",
    "description": "Surgical consumables, medical equipment static ads, and story campaign creatives.",
    "coverImage": "/raw_assets/graphics/Meddipro/Mediprro _ Surgical Consumables_ Static_1-1_Dec2025 (1080 x 1920 px) (1).png",
    "images": [
      {
        "filename": "Mediprro _ Surgical Consumables_ Static_1-1_Dec2025 (1080 x 1920 px) (1).png",
        "url": "/raw_assets/graphics/Meddipro/Mediprro _ Surgical Consumables_ Static_1-1_Dec2025 (1080 x 1920 px) (1).png"
      },
      {
        "filename": "Mediprro _ Surgical Consumables_ Static_1-1_Dec2025 (1080 x 1920 px) (4).png",
        "url": "/raw_assets/graphics/Meddipro/Mediprro _ Surgical Consumables_ Static_1-1_Dec2025 (1080 x 1920 px) (4).png"
      },
      {
        "filename": "Mediprro _ Surgical Consumables_ Static_1-1_Dec2025 (1080 x 1920 px) (5).png",
        "url": "/raw_assets/graphics/Meddipro/Mediprro _ Surgical Consumables_ Static_1-1_Dec2025 (1080 x 1920 px) (5).png"
      },
      {
        "filename": "Mediprro _ Surgical Consumables_ Static_1-1_Dec2025 (2).png",
        "url": "/raw_assets/graphics/Meddipro/Mediprro _ Surgical Consumables_ Static_1-1_Dec2025 (2).png"
      },
      {
        "filename": "Mediprro _ Surgical Consumables_ Static_1-1_Dec2025 (20).png",
        "url": "/raw_assets/graphics/Meddipro/Mediprro _ Surgical Consumables_ Static_1-1_Dec2025 (20).png"
      },
      {
        "filename": "Mediprro _ Surgical Consumables_ Static_1-1_Dec2025 (6).png",
        "url": "/raw_assets/graphics/Meddipro/Mediprro _ Surgical Consumables_ Static_1-1_Dec2025 (6).png"
      }
    ],
    "type": "carousel",
    "itemCount": 6
  },
  {
    "id": "gfx-perroquetta-roofing-sheets",
    "category": "Graphics Design",
    "brand": "Perroquetta Roofing",
    "folderName": "Perroquetta Roofing Sheets",
    "title": "Perroquetta Roofing Social & Ad Creatives",
    "tag": "Building & Architecture",
    "description": "UPVC roofing sheets product awareness, mobile statics, and home exterior posts.",
    "coverImage": "/raw_assets/graphics/Perroquetta Roofing Sheets/Perroqueta UPVC Sheet Static - July 2026 (6).png",
    "images": [
      {
        "filename": "Perroqueta UPVC Sheet Static - July 2026 (6).png",
        "url": "/raw_assets/graphics/Perroquetta Roofing Sheets/Perroqueta UPVC Sheet Static - July 2026 (6).png"
      },
      {
        "filename": "Perroqueta UPVC Sheet StaticMobile_Aug2025 (1800 x 1800 px) (2).png",
        "url": "/raw_assets/graphics/Perroquetta Roofing Sheets/Perroqueta UPVC Sheet StaticMobile_Aug2025 (1800 x 1800 px) (2).png"
      },
      {
        "filename": "Perroqueta UPVC Sheet StaticMobile_Aug2025 (1800 x 1800 px) (3).png",
        "url": "/raw_assets/graphics/Perroquetta Roofing Sheets/Perroqueta UPVC Sheet StaticMobile_Aug2025 (1800 x 1800 px) (3).png"
      },
      {
        "filename": "The Roof Your Home Deserves! (1).png",
        "url": "/raw_assets/graphics/Perroquetta Roofing Sheets/The Roof Your Home Deserves! (1).png"
      },
      {
        "filename": "The Roof Your Home Deserves! (1080 x 1920 px) (2).png",
        "url": "/raw_assets/graphics/Perroquetta Roofing Sheets/The Roof Your Home Deserves! (1080 x 1920 px) (2).png"
      },
      {
        "filename": "perroqueta _Static_1-1.png",
        "url": "/raw_assets/graphics/Perroquetta Roofing Sheets/perroqueta _Static_1-1.png"
      }
    ],
    "type": "carousel",
    "itemCount": 6
  },
  {
    "id": "gfx-pupa",
    "category": "Graphics Design",
    "brand": "Pupa",
    "folderName": "Pupa",
    "title": "Pupa Social & Ad Creatives",
    "tag": "Product & Hiring Creatives",
    "description": "Product awareness posts, bulk order campaigns, and corporate hiring announcements.",
    "coverImage": "/raw_assets/graphics/Pupa/Hiring Post for thenneera and pupa.png",
    "images": [
      {
        "filename": "Hiring Post for thenneera and pupa.png",
        "url": "/raw_assets/graphics/Pupa/Hiring Post for thenneera and pupa.png"
      },
      {
        "filename": "Pupa - Bulk order creatives_ Post 1-1_April1 .png",
        "url": "/raw_assets/graphics/Pupa/Pupa - Bulk order creatives_ Post 1-1_April1 .png"
      },
      {
        "filename": "Pupa - Distributor _Static_creatives_May2025_1-1 - Option 2.png",
        "url": "/raw_assets/graphics/Pupa/Pupa - Distributor _Static_creatives_May2025_1-1 - Option 2.png"
      },
      {
        "filename": "Pupa_Product Awareness_Creative_1-1.png",
        "url": "/raw_assets/graphics/Pupa/Pupa_Product Awareness_Creative_1-1.png"
      }
    ],
    "type": "carousel",
    "itemCount": 4
  },
  {
    "id": "gfx-rk-ecran",
    "category": "Graphics Design",
    "brand": "RK Ecran",
    "folderName": "RK Ecran",
    "title": "RK Ecran Social & Ad Creatives",
    "tag": "Home Protection Solutions",
    "description": "Barrier-free protection, mosquito screens, and sliding door product campaigns.",
    "coverImage": "/raw_assets/graphics/RK Ecran/1.png",
    "images": [
      {
        "filename": "1.png",
        "url": "/raw_assets/graphics/RK Ecran/1.png"
      },
      {
        "filename": "14.png",
        "url": "/raw_assets/graphics/RK Ecran/14.png"
      },
      {
        "filename": "17.png",
        "url": "/raw_assets/graphics/RK Ecran/17.png"
      },
      {
        "filename": "4.png",
        "url": "/raw_assets/graphics/RK Ecran/4.png"
      },
      {
        "filename": "5.png",
        "url": "/raw_assets/graphics/RK Ecran/5.png"
      },
      {
        "filename": "7.png",
        "url": "/raw_assets/graphics/RK Ecran/7.png"
      },
      {
        "filename": "PET FRIENDLY SOLUTION.png",
        "url": "/raw_assets/graphics/RK Ecran/PET FRIENDLY SOLUTION.png"
      },
      {
        "filename": "RK Ecran Static- 1-1 - Sliding Mosquito Door (25).png",
        "url": "/raw_assets/graphics/RK Ecran/RK Ecran Static- 1-1 - Sliding Mosquito Door (25).png"
      },
      {
        "filename": "RK ecran creatives - Static - June 2026 (1).png",
        "url": "/raw_assets/graphics/RK Ecran/RK ecran creatives - Static - June 2026 (1).png"
      },
      {
        "filename": "Rk ecran-Barrier-Free Protection.png",
        "url": "/raw_assets/graphics/RK Ecran/Rk ecran-Barrier-Free Protection.png"
      }
    ],
    "type": "carousel",
    "itemCount": 10
  },
  {
    "id": "gfx-sumangali",
    "category": "Graphics Design",
    "brand": "Sumangali Jewellery",
    "folderName": "Sumangali",
    "title": "Sumangali Jewellery Social & Ad Creatives",
    "tag": "Luxury Jewellery Ads",
    "description": "High-end luxury gold, diamond, and bridal jewellery promotional campaigns and social creatives.",
    "coverImage": "/raw_assets/graphics/Sumangali/SJ Jan 12.jpg",
    "images": [
      {
        "filename": "SJ Jan 12.jpg",
        "url": "/raw_assets/graphics/Sumangali/SJ Jan 12.jpg"
      },
      {
        "filename": "SJ Jan 13.jpg",
        "url": "/raw_assets/graphics/Sumangali/SJ Jan 13.jpg"
      },
      {
        "filename": "SJ Jan 4.jpg",
        "url": "/raw_assets/graphics/Sumangali/SJ Jan 4.jpg"
      },
      {
        "filename": "SJ Jan 5.jpg",
        "url": "/raw_assets/graphics/Sumangali/SJ Jan 5.jpg"
      },
      {
        "filename": "SJ Jan 6.jpg",
        "url": "/raw_assets/graphics/Sumangali/SJ Jan 6.jpg"
      },
      {
        "filename": "SJ Jan 7.jpg",
        "url": "/raw_assets/graphics/Sumangali/SJ Jan 7.jpg"
      },
      {
        "filename": "SJ Jan 8.jpg",
        "url": "/raw_assets/graphics/Sumangali/SJ Jan 8.jpg"
      },
      {
        "filename": "SJ Jan 9.jpg",
        "url": "/raw_assets/graphics/Sumangali/SJ Jan 9.jpg"
      },
      {
        "filename": "SJ Jewellery Dec 19.jpg",
        "url": "/raw_assets/graphics/Sumangali/SJ Jewellery Dec 19.jpg"
      },
      {
        "filename": "SJ Jewellery Dec 2.jpg",
        "url": "/raw_assets/graphics/Sumangali/SJ Jewellery Dec 2.jpg"
      },
      {
        "filename": "SJ Jewellery Dec15.jpg",
        "url": "/raw_assets/graphics/Sumangali/SJ Jewellery Dec15.jpg"
      },
      {
        "filename": "SJ Jewellery Dec16.jpg",
        "url": "/raw_assets/graphics/Sumangali/SJ Jewellery Dec16.jpg"
      },
      {
        "filename": "SJ Jewellery Dec20.jpg",
        "url": "/raw_assets/graphics/Sumangali/SJ Jewellery Dec20.jpg"
      },
      {
        "filename": "SJ Jewellery Dec22.jpg",
        "url": "/raw_assets/graphics/Sumangali/SJ Jewellery Dec22.jpg"
      },
      {
        "filename": "SJ Jewellery Nov 12.jpg",
        "url": "/raw_assets/graphics/Sumangali/SJ Jewellery Nov 12.jpg"
      },
      {
        "filename": "SJ Jewellery Nov 13.jpg",
        "url": "/raw_assets/graphics/Sumangali/SJ Jewellery Nov 13.jpg"
      },
      {
        "filename": "SJ Jewellery Nov 4.jpg",
        "url": "/raw_assets/graphics/Sumangali/SJ Jewellery Nov 4.jpg"
      },
      {
        "filename": "SJ Jewellery Nov 6.jpeg",
        "url": "/raw_assets/graphics/Sumangali/SJ Jewellery Nov 6.jpeg"
      },
      {
        "filename": "SJ Jewellery Nov 6.jpg",
        "url": "/raw_assets/graphics/Sumangali/SJ Jewellery Nov 6.jpg"
      },
      {
        "filename": "SJ Jewellery dec18.jpg",
        "url": "/raw_assets/graphics/Sumangali/SJ Jewellery dec18.jpg"
      },
      {
        "filename": "SJ Jewellery nov3.jpg",
        "url": "/raw_assets/graphics/Sumangali/SJ Jewellery nov3.jpg"
      },
      {
        "filename": "Sumangali August 15.jpg",
        "url": "/raw_assets/graphics/Sumangali/Sumangali August 15.jpg"
      },
      {
        "filename": "Sumangali August 16.jpg",
        "url": "/raw_assets/graphics/Sumangali/Sumangali August 16.jpg"
      },
      {
        "filename": "Sumangali August 17.jpg",
        "url": "/raw_assets/graphics/Sumangali/Sumangali August 17.jpg"
      },
      {
        "filename": "Sumangali August 18.jpg",
        "url": "/raw_assets/graphics/Sumangali/Sumangali August 18.jpg"
      },
      {
        "filename": "Sumangali August 21.jpg",
        "url": "/raw_assets/graphics/Sumangali/Sumangali August 21.jpg"
      },
      {
        "filename": "Sumangali August 22.jpg",
        "url": "/raw_assets/graphics/Sumangali/Sumangali August 22.jpg"
      },
      {
        "filename": "Sumangali August 25.jpg",
        "url": "/raw_assets/graphics/Sumangali/Sumangali August 25.jpg"
      },
      {
        "filename": "Sumangali August 26.jpg",
        "url": "/raw_assets/graphics/Sumangali/Sumangali August 26.jpg"
      },
      {
        "filename": "Sumangali August 26_1.jpg",
        "url": "/raw_assets/graphics/Sumangali/Sumangali August 26_1.jpg"
      },
      {
        "filename": "Sumangali August 27_1.jpg",
        "url": "/raw_assets/graphics/Sumangali/Sumangali August 27_1.jpg"
      },
      {
        "filename": "Sumangali August 6.jpg",
        "url": "/raw_assets/graphics/Sumangali/Sumangali August 6.jpg"
      },
      {
        "filename": "Sumangali August 7.jpg",
        "url": "/raw_assets/graphics/Sumangali/Sumangali August 7.jpg"
      },
      {
        "filename": "Sumangali August 8.jpg",
        "url": "/raw_assets/graphics/Sumangali/Sumangali August 8.jpg"
      },
      {
        "filename": "Sumangali Jul 12.jpg",
        "url": "/raw_assets/graphics/Sumangali/Sumangali Jul 12.jpg"
      },
      {
        "filename": "Sumangali Jul 14.jpg",
        "url": "/raw_assets/graphics/Sumangali/Sumangali Jul 14.jpg"
      },
      {
        "filename": "Sumangali Jul 15.jpg",
        "url": "/raw_assets/graphics/Sumangali/Sumangali Jul 15.jpg"
      },
      {
        "filename": "Sumangali Jul 16.jpg",
        "url": "/raw_assets/graphics/Sumangali/Sumangali Jul 16.jpg"
      },
      {
        "filename": "Sumangali Jul 17.jpg",
        "url": "/raw_assets/graphics/Sumangali/Sumangali Jul 17.jpg"
      },
      {
        "filename": "Sumangali Jul 18.jpg",
        "url": "/raw_assets/graphics/Sumangali/Sumangali Jul 18.jpg"
      },
      {
        "filename": "Sumangali Jul 19.jpg",
        "url": "/raw_assets/graphics/Sumangali/Sumangali Jul 19.jpg"
      },
      {
        "filename": "Sumangali Jul 20.jpg",
        "url": "/raw_assets/graphics/Sumangali/Sumangali Jul 20.jpg"
      },
      {
        "filename": "Sumangali Jul 21.jpg",
        "url": "/raw_assets/graphics/Sumangali/Sumangali Jul 21.jpg"
      },
      {
        "filename": "Sumangali Jul 22.jpg",
        "url": "/raw_assets/graphics/Sumangali/Sumangali Jul 22.jpg"
      },
      {
        "filename": "Sumangali Jul 23.jpg",
        "url": "/raw_assets/graphics/Sumangali/Sumangali Jul 23.jpg"
      },
      {
        "filename": "Sumangali Jul 24.jpg",
        "url": "/raw_assets/graphics/Sumangali/Sumangali Jul 24.jpg"
      },
      {
        "filename": "Sumangali Jul 25.jpg",
        "url": "/raw_assets/graphics/Sumangali/Sumangali Jul 25.jpg"
      },
      {
        "filename": "Sumangali Jul 26.jpg",
        "url": "/raw_assets/graphics/Sumangali/Sumangali Jul 26.jpg"
      },
      {
        "filename": "Sumangali July 1.jpg",
        "url": "/raw_assets/graphics/Sumangali/Sumangali July 1.jpg"
      },
      {
        "filename": "Sumangali July 2.jpg",
        "url": "/raw_assets/graphics/Sumangali/Sumangali July 2.jpg"
      },
      {
        "filename": "Sumangali Sep 10.jpg",
        "url": "/raw_assets/graphics/Sumangali/Sumangali Sep 10.jpg"
      },
      {
        "filename": "Sumangali Sep 11.jpg",
        "url": "/raw_assets/graphics/Sumangali/Sumangali Sep 11.jpg"
      },
      {
        "filename": "Sumangali Sep 26.jpg",
        "url": "/raw_assets/graphics/Sumangali/Sumangali Sep 26.jpg"
      },
      {
        "filename": "Sumangali Sep 3.jpg",
        "url": "/raw_assets/graphics/Sumangali/Sumangali Sep 3.jpg"
      },
      {
        "filename": "Sumangali Sep 4.jpg",
        "url": "/raw_assets/graphics/Sumangali/Sumangali Sep 4.jpg"
      },
      {
        "filename": "Sumangali Sep 7.jpg",
        "url": "/raw_assets/graphics/Sumangali/Sumangali Sep 7.jpg"
      },
      {
        "filename": "Sumangali Sep 8.jpg",
        "url": "/raw_assets/graphics/Sumangali/Sumangali Sep 8.jpg"
      },
      {
        "filename": "Sumangali Sep 9.jpg",
        "url": "/raw_assets/graphics/Sumangali/Sumangali Sep 9.jpg"
      },
      {
        "filename": "Sumangali oct 9.jpg",
        "url": "/raw_assets/graphics/Sumangali/Sumangali oct 9.jpg"
      },
      {
        "filename": "Sumangali sep 16.jpg",
        "url": "/raw_assets/graphics/Sumangali/Sumangali sep 16.jpg"
      },
      {
        "filename": "Sumangali sep 17.jpg",
        "url": "/raw_assets/graphics/Sumangali/Sumangali sep 17.jpg"
      },
      {
        "filename": "Sumangali sep 18.jpg",
        "url": "/raw_assets/graphics/Sumangali/Sumangali sep 18.jpg"
      },
      {
        "filename": "Sumangali sep 24.jpg",
        "url": "/raw_assets/graphics/Sumangali/Sumangali sep 24.jpg"
      }
    ],
    "type": "carousel",
    "itemCount": 63
  },
  {
    "id": "gfx-techno-sports",
    "category": "Graphics Design",
    "brand": "Techno Sports",
    "folderName": "Techno sports",
    "title": "Techno Sports Social & Ad Creatives",
    "tag": "Sportswear & Fitness",
    "description": "Modern premium sportswear graphics and activewear promotional posts.",
    "coverImage": "/raw_assets/graphics/Techno sports/2.png",
    "images": [
      {
        "filename": "2.png",
        "url": "/raw_assets/graphics/Techno sports/2.png"
      },
      {
        "filename": "Navy Yellow Modern Premium Sportwear Twitter Post (1800 x 1800 px) (1080 x 1920 px) (1).png",
        "url": "/raw_assets/graphics/Techno sports/Navy Yellow Modern Premium Sportwear Twitter Post (1800 x 1800 px) (1080 x 1920 px) (1).png"
      }
    ],
    "type": "carousel",
    "itemCount": 2
  },
  {
    "id": "gfx-thenneera",
    "category": "Graphics Design",
    "brand": "Thenneera",
    "folderName": "Thenneera",
    "title": "Thenneera Social & Ad Creatives",
    "tag": "Natural Beverage FMCG",
    "description": "Hyper-local awareness campaigns, distributor onboarding carousels, and meet & greet posts.",
    "coverImage": "/raw_assets/graphics/Thenneera/1.png",
    "images": [
      {
        "filename": "1.png",
        "url": "/raw_assets/graphics/Thenneera/1.png"
      },
      {
        "filename": "2.png",
        "url": "/raw_assets/graphics/Thenneera/2.png"
      },
      {
        "filename": "3.png",
        "url": "/raw_assets/graphics/Thenneera/3.png"
      },
      {
        "filename": "Meet and Greet Thennera_Post1-1.png",
        "url": "/raw_assets/graphics/Thenneera/Meet and Greet Thennera_Post1-1.png"
      },
      {
        "filename": "Thenneera_ Hyper local awareness campaign 2_Static_March2025_1-1.png",
        "url": "/raw_assets/graphics/Thenneera/Thenneera_ Hyper local awareness campaign 2_Static_March2025_1-1.png"
      },
      {
        "filename": "Thenneera_ Hyper local awareness campaign_Static_March2025_1-1.png",
        "url": "/raw_assets/graphics/Thenneera/Thenneera_ Hyper local awareness campaign_Static_March2025_1-1.png"
      },
      {
        "filename": "Thenneera_Static_1-1_Aug2025.png",
        "url": "/raw_assets/graphics/Thenneera/Thenneera_Static_1-1_Aug2025.png"
      },
      {
        "filename": "_Thenneera_Distributor onboarding_Carousel _Jan2025_1-1 (1).png",
        "url": "/raw_assets/graphics/Thenneera/_Thenneera_Distributor onboarding_Carousel _Jan2025_1-1 (1).png"
      }
    ],
    "type": "carousel",
    "itemCount": 8
  },
  {
    "id": "gfx-vakaman-developers",
    "category": "Graphics Design",
    "brand": "Vakaman Developers",
    "folderName": "Vakaman Developers",
    "title": "Vakaman Developers Social & Ad Creatives",
    "tag": "Real Estate Campaigns",
    "description": "Luxury real estate, Amber carousels, and architectural property launch static posts.",
    "coverImage": "/raw_assets/graphics/Vakaman Developers/3.png",
    "images": [
      {
        "filename": "3.png",
        "url": "/raw_assets/graphics/Vakaman Developers/3.png"
      },
      {
        "filename": "5.png",
        "url": "/raw_assets/graphics/Vakaman Developers/5.png"
      },
      {
        "filename": "C1.png",
        "url": "/raw_assets/graphics/Vakaman Developers/C1.png"
      },
      {
        "filename": "C2.png",
        "url": "/raw_assets/graphics/Vakaman Developers/C2.png"
      },
      {
        "filename": "C3.png",
        "url": "/raw_assets/graphics/Vakaman Developers/C3.png"
      },
      {
        "filename": "C4.png",
        "url": "/raw_assets/graphics/Vakaman Developers/C4.png"
      },
      {
        "filename": "C5.png",
        "url": "/raw_assets/graphics/Vakaman Developers/C5.png"
      },
      {
        "filename": "Riva _ Static_1-1_Nov2025 (6).png",
        "url": "/raw_assets/graphics/Vakaman Developers/Riva _ Static_1-1_Nov2025 (6).png"
      },
      {
        "filename": "Vakaman - 1 _Amber_Carousel_Nov2025.png",
        "url": "/raw_assets/graphics/Vakaman Developers/Vakaman - 1 _Amber_Carousel_Nov2025.png"
      },
      {
        "filename": "Vakaman - 2 _Amber_Carousel_Nov2025.png",
        "url": "/raw_assets/graphics/Vakaman Developers/Vakaman - 2 _Amber_Carousel_Nov2025.png"
      },
      {
        "filename": "Vakaman - 3 _Amber_Carousel_Nov2025.png",
        "url": "/raw_assets/graphics/Vakaman Developers/Vakaman - 3 _Amber_Carousel_Nov2025.png"
      },
      {
        "filename": "Vakaman Static _1-1_Oct2025.png",
        "url": "/raw_assets/graphics/Vakaman Developers/Vakaman Static _1-1_Oct2025.png"
      }
    ],
    "type": "carousel",
    "itemCount": 12
  },
  {
    "id": "logo-dall_labs_style_guide_final_copy-1",
    "category": "Logo & Brand Identity",
    "brand": "Dall Labs Style Guide",
    "title": "Dall Labs Style Guide - Identity System",
    "tag": "Brand Identity & Style Guide",
    "description": "Complete visual identity, typography system, brand color palettes, and logo usage guidelines for Dall Labs.",
    "pdfUrl": "/raw_assets/logos/dall labs style guide final copy-1.pdf",
    "coverImage": "/raw_assets/pdf_previews/dall_labs_style_guide_final_copy-1-01.png",
    "pages": [
      {
        "filename": "dall_labs_style_guide_final_copy-1-01.png",
        "url": "/raw_assets/pdf_previews/dall_labs_style_guide_final_copy-1-01.png"
      },
      {
        "filename": "dall_labs_style_guide_final_copy-1-02.png",
        "url": "/raw_assets/pdf_previews/dall_labs_style_guide_final_copy-1-02.png"
      },
      {
        "filename": "dall_labs_style_guide_final_copy-1-03.png",
        "url": "/raw_assets/pdf_previews/dall_labs_style_guide_final_copy-1-03.png"
      },
      {
        "filename": "dall_labs_style_guide_final_copy-1-04.png",
        "url": "/raw_assets/pdf_previews/dall_labs_style_guide_final_copy-1-04.png"
      },
      {
        "filename": "dall_labs_style_guide_final_copy-1-05.png",
        "url": "/raw_assets/pdf_previews/dall_labs_style_guide_final_copy-1-05.png"
      },
      {
        "filename": "dall_labs_style_guide_final_copy-1-06.png",
        "url": "/raw_assets/pdf_previews/dall_labs_style_guide_final_copy-1-06.png"
      },
      {
        "filename": "dall_labs_style_guide_final_copy-1-07.png",
        "url": "/raw_assets/pdf_previews/dall_labs_style_guide_final_copy-1-07.png"
      },
      {
        "filename": "dall_labs_style_guide_final_copy-1-08.png",
        "url": "/raw_assets/pdf_previews/dall_labs_style_guide_final_copy-1-08.png"
      },
      {
        "filename": "dall_labs_style_guide_final_copy-1-09.png",
        "url": "/raw_assets/pdf_previews/dall_labs_style_guide_final_copy-1-09.png"
      },
      {
        "filename": "dall_labs_style_guide_final_copy-1-10.png",
        "url": "/raw_assets/pdf_previews/dall_labs_style_guide_final_copy-1-10.png"
      },
      {
        "filename": "dall_labs_style_guide_final_copy-1-11.png",
        "url": "/raw_assets/pdf_previews/dall_labs_style_guide_final_copy-1-11.png"
      },
      {
        "filename": "dall_labs_style_guide_final_copy-1-12.png",
        "url": "/raw_assets/pdf_previews/dall_labs_style_guide_final_copy-1-12.png"
      },
      {
        "filename": "dall_labs_style_guide_final_copy-1-13.png",
        "url": "/raw_assets/pdf_previews/dall_labs_style_guide_final_copy-1-13.png"
      },
      {
        "filename": "dall_labs_style_guide_final_copy-1-14.png",
        "url": "/raw_assets/pdf_previews/dall_labs_style_guide_final_copy-1-14.png"
      },
      {
        "filename": "dall_labs_style_guide_final_copy-1-15.png",
        "url": "/raw_assets/pdf_previews/dall_labs_style_guide_final_copy-1-15.png"
      }
    ],
    "pageCount": 15,
    "type": "pdf_booklet",
    "itemCount": 15
  },
  {
    "id": "logo-invictus_final",
    "category": "Logo & Brand Identity",
    "brand": "Invictus Brand Identity",
    "title": "Invictus Brand Identity - Identity System",
    "tag": "Corporate Identity & Logo System",
    "description": "Comprehensive corporate brand guidelines, emblem design, icon grid, and stationery mockups.",
    "pdfUrl": "/raw_assets/logos/Invictus final.pdf",
    "coverImage": "/raw_assets/pdf_previews/invictus_final-01.png",
    "pages": [
      {
        "filename": "invictus_final-01.png",
        "url": "/raw_assets/pdf_previews/invictus_final-01.png"
      },
      {
        "filename": "invictus_final-02.png",
        "url": "/raw_assets/pdf_previews/invictus_final-02.png"
      },
      {
        "filename": "invictus_final-03.png",
        "url": "/raw_assets/pdf_previews/invictus_final-03.png"
      },
      {
        "filename": "invictus_final-04.png",
        "url": "/raw_assets/pdf_previews/invictus_final-04.png"
      },
      {
        "filename": "invictus_final-05.png",
        "url": "/raw_assets/pdf_previews/invictus_final-05.png"
      },
      {
        "filename": "invictus_final-06.png",
        "url": "/raw_assets/pdf_previews/invictus_final-06.png"
      },
      {
        "filename": "invictus_final-07.png",
        "url": "/raw_assets/pdf_previews/invictus_final-07.png"
      },
      {
        "filename": "invictus_final-08.png",
        "url": "/raw_assets/pdf_previews/invictus_final-08.png"
      },
      {
        "filename": "invictus_final-09.png",
        "url": "/raw_assets/pdf_previews/invictus_final-09.png"
      },
      {
        "filename": "invictus_final-10.png",
        "url": "/raw_assets/pdf_previews/invictus_final-10.png"
      }
    ],
    "pageCount": 10,
    "type": "pdf_booklet",
    "itemCount": 10
  },
  {
    "id": "logo-snacko_brand_guidelins_v1",
    "category": "Logo & Brand Identity",
    "brand": "Snacko Brand Guidelines",
    "title": "Snacko Brand Guidelines - Identity System",
    "tag": "FMCG Brand Guidelines",
    "description": "Vibrant packaging identity, logo construction, color theory, and packaging mockups for Snacko brand.",
    "pdfUrl": "/raw_assets/logos/Snacko brand guidelins_V1.pdf",
    "coverImage": "/raw_assets/pdf_previews/snacko_brand_guidelins_v1-01.png",
    "pages": [
      {
        "filename": "snacko_brand_guidelins_v1-01.png",
        "url": "/raw_assets/pdf_previews/snacko_brand_guidelins_v1-01.png"
      },
      {
        "filename": "snacko_brand_guidelins_v1-02.png",
        "url": "/raw_assets/pdf_previews/snacko_brand_guidelins_v1-02.png"
      },
      {
        "filename": "snacko_brand_guidelins_v1-03.png",
        "url": "/raw_assets/pdf_previews/snacko_brand_guidelins_v1-03.png"
      },
      {
        "filename": "snacko_brand_guidelins_v1-04.png",
        "url": "/raw_assets/pdf_previews/snacko_brand_guidelins_v1-04.png"
      },
      {
        "filename": "snacko_brand_guidelins_v1-05.png",
        "url": "/raw_assets/pdf_previews/snacko_brand_guidelins_v1-05.png"
      },
      {
        "filename": "snacko_brand_guidelins_v1-06.png",
        "url": "/raw_assets/pdf_previews/snacko_brand_guidelins_v1-06.png"
      },
      {
        "filename": "snacko_brand_guidelins_v1-07.png",
        "url": "/raw_assets/pdf_previews/snacko_brand_guidelins_v1-07.png"
      },
      {
        "filename": "snacko_brand_guidelins_v1-08.png",
        "url": "/raw_assets/pdf_previews/snacko_brand_guidelins_v1-08.png"
      },
      {
        "filename": "snacko_brand_guidelins_v1-09.png",
        "url": "/raw_assets/pdf_previews/snacko_brand_guidelins_v1-09.png"
      },
      {
        "filename": "snacko_brand_guidelins_v1-10.png",
        "url": "/raw_assets/pdf_previews/snacko_brand_guidelins_v1-10.png"
      },
      {
        "filename": "snacko_brand_guidelins_v1-11.png",
        "url": "/raw_assets/pdf_previews/snacko_brand_guidelins_v1-11.png"
      },
      {
        "filename": "snacko_brand_guidelins_v1-12.png",
        "url": "/raw_assets/pdf_previews/snacko_brand_guidelins_v1-12.png"
      },
      {
        "filename": "snacko_brand_guidelins_v1-13.png",
        "url": "/raw_assets/pdf_previews/snacko_brand_guidelins_v1-13.png"
      },
      {
        "filename": "snacko_brand_guidelins_v1-14.png",
        "url": "/raw_assets/pdf_previews/snacko_brand_guidelins_v1-14.png"
      },
      {
        "filename": "snacko_brand_guidelins_v1-15.png",
        "url": "/raw_assets/pdf_previews/snacko_brand_guidelins_v1-15.png"
      },
      {
        "filename": "snacko_brand_guidelins_v1-16.png",
        "url": "/raw_assets/pdf_previews/snacko_brand_guidelins_v1-16.png"
      },
      {
        "filename": "snacko_brand_guidelins_v1-17.png",
        "url": "/raw_assets/pdf_previews/snacko_brand_guidelins_v1-17.png"
      }
    ],
    "pageCount": 17,
    "type": "pdf_booklet",
    "itemCount": 17
  },
  {
    "id": "logo-zootoca_logo_work_copy",
    "category": "Logo & Brand Identity",
    "brand": "Zootoca Logo Design",
    "title": "Zootoca Logo Design - Identity System",
    "tag": "Logo Exploration & Concept",
    "description": "Logo conceptualization, vector mark variations, color options, and brand application.",
    "pdfUrl": "/raw_assets/logos/zootoca logo work copy.pdf",
    "coverImage": "/raw_assets/pdf_previews/zootoca_logo_work_copy-1.png",
    "pages": [
      {
        "filename": "zootoca_logo_work_copy-1.png",
        "url": "/raw_assets/pdf_previews/zootoca_logo_work_copy-1.png"
      },
      {
        "filename": "zootoca_logo_work_copy-2.png",
        "url": "/raw_assets/pdf_previews/zootoca_logo_work_copy-2.png"
      },
      {
        "filename": "zootoca_logo_work_copy-3.png",
        "url": "/raw_assets/pdf_previews/zootoca_logo_work_copy-3.png"
      },
      {
        "filename": "zootoca_logo_work_copy-4.png",
        "url": "/raw_assets/pdf_previews/zootoca_logo_work_copy-4.png"
      },
      {
        "filename": "zootoca_logo_work_copy-5.png",
        "url": "/raw_assets/pdf_previews/zootoca_logo_work_copy-5.png"
      }
    ],
    "pageCount": 5,
    "type": "pdf_booklet",
    "itemCount": 5
  },
  {
    "id": "logo-digiobz_6",
    "category": "Logo & Brand Identity",
    "brand": "Digiobz Logo Design",
    "title": "Digiobz Logo Design - Identity System",
    "tag": "Digital Agency Logo",
    "description": "Modern digital agency logo typography and geometric icon design.",
    "pdfUrl": "/raw_assets/logos/digiobz 6.pdf",
    "coverImage": "/raw_assets/pdf_previews/digiobz_6-1.png",
    "pages": [
      {
        "filename": "digiobz_6-1.png",
        "url": "/raw_assets/pdf_previews/digiobz_6-1.png"
      }
    ],
    "pageCount": 1,
    "type": "pdf_booklet",
    "itemCount": 1
  },
  {
    "id": "video-bocs-pizza",
    "category": "Video Editing",
    "brand": "BOCS Pizza Theater Ad",
    "title": "BOCS Pizza Theater Ad Motion Reels",
    "tag": "Cinema & Social Ad",
    "description": "High-energy theater commercial video ad designed for big-screen promotional campaigns.",
    "coverImage": "",
    "videos": [
      {
        "filename": "tuty theater add video.mp4",
        "url": "/raw_assets/videos/BOCS PIZZA/tuty theater add video.mp4",
        "title": "tuty theater add video"
      }
    ],
    "type": "video_gallery",
    "itemCount": 1
  },
  {
    "id": "video-rk-ecran",
    "category": "Video Editing",
    "brand": "RK Ecran Promo Video",
    "title": "RK Ecran Promo Video Motion Reels",
    "tag": "Product Motion Reel",
    "description": "Product feature walkthrough video with engaging animated motion graphics.",
    "coverImage": "",
    "videos": [
      {
        "filename": "Rk - Ecran video - March - 3.mp4",
        "url": "/raw_assets/videos/RK Ecran/Rk - Ecran video - March - 3.mp4",
        "title": "Rk - Ecran video - March - 3"
      }
    ],
    "type": "video_gallery",
    "itemCount": 1
  },
  {
    "id": "video-topaaz",
    "category": "Video Editing",
    "brand": "Topaaz Commercial Reels",
    "title": "Topaaz Commercial Reels Motion Reels",
    "tag": "Commercial & Testimonials",
    "description": "Product launch video, manufacturer reel, and customer testimonial video edits.",
    "coverImage": "",
    "videos": [
      {
        "filename": "Topaaz - Manufacturers Video - june - 2026.mp4",
        "url": "/raw_assets/videos/Topaaz/Topaaz - Manufacturers Video - june - 2026.mp4",
        "title": "Topaaz - Manufacturers Video - june - 2026"
      },
      {
        "filename": "Topaaz - Video - Final - April 2026 (2).mp4",
        "url": "/raw_assets/videos/Topaaz/Topaaz - Video - Final - April 2026 (2).mp4",
        "title": "Topaaz - Video - Final - April 2026 (2)"
      },
      {
        "filename": "Topaaz - Video - May 2026 (Video).mp4",
        "url": "/raw_assets/videos/Topaaz/Topaaz - Video - May 2026 (Video).mp4",
        "title": "Topaaz - Video - May 2026 (Video)"
      },
      {
        "filename": "TopaazvTestimonial  Video - July 2026.mp4",
        "url": "/raw_assets/videos/Topaaz/TopaazvTestimonial  Video - July 2026.mp4",
        "title": "TopaazvTestimonial  Video - July 2026"
      }
    ],
    "type": "video_gallery",
    "itemCount": 4
  }
];

export const CLIENT_BRANDS = [
  { name: 'Sumangali Jewellery', category: 'Jewellery & Luxury', logo: '💎' },
  { name: 'Vakaman Developers', category: 'Real Estate', logo: '🏢' },
  { name: 'BOCS Pizza', category: 'F&B Restaurant', logo: '🍕' },
  { name: 'Dall Labs', category: 'Tech & AI', logo: '🔬' },
  { name: 'Curry Life', category: 'FMCG Food', logo: '🍲' },
  { name: 'Topaaz', category: 'Manufacturing', logo: '⚙️' },
  { name: 'Invictus', category: 'Corporate', logo: '🛡️' },
  { name: 'E-Now Batteries', category: 'Energy & Tech', logo: '⚡' },
  { name: 'RK Ecran', category: 'Home Interiors', logo: '🏡' },
  { name: 'Thenneera', category: 'Natural Beverages', logo: '🥥' },
  { name: 'Snacko', category: 'Snack Food', logo: '🍟' },
  { name: 'Meddipro', category: 'Healthcare', logo: '🏥' },
  { name: 'Perroquetta', category: 'Building Materials', logo: '🏗️' }
];
